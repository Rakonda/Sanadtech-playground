import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import { connect } from "react-redux";
import * as action from "./actions";

import TypeInput from "./TypeInput";
import TypeList from "./TypeList";

const storeConnect = store => {
  return {
    // store: store
  };
};

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    console.log(this.props);
    // this.props.dispatch(action.fetchSchema());

    if (typeof localStorage.getItem("state") === "object") {
      console.log("set storage");
      localStorage.setItem("state", JSON.stringify([]));
    } else {
      this.listofitems = JSON.parse(localStorage.getItem("state"));
    }
  }

  listofitems = [];

  updateStore = () => {
    this.props.dispatch(action.fetchItems(this.listofitems));
  };

  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <button onClick={this.updateStore}>update Store</button>

        <TypeInput />
        <TypeList />
      </div>
    );
  }
}

// export default App;
export default connect(storeConnect)(App);
