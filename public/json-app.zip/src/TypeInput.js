import React, { Component } from "react";
import "./App.css";
import { connect } from "react-redux";
import * as action from "./actions";

const storeConnect = store => {
  return {
    store: store
  };
};

class TypeInput extends Component {
  schema = {
    id: Math.floor(Math.random() * 201),
    name: "Default name",
    type: "String",
    items: ""
  };

  schema_types = ["String", "Number", "Array", "Object"];

  constructor(props) {
    super(props);
    console.log(this.props);
    this.state = {
      id: Math.floor(Math.random() * 201),
      name: "Default name",
      type: "String",
      items: ""
    };
  }

  onChange = e => {
    this.setState({
      name: e.target.value
    });
  };

  onChangeSelect = e => {
    console.log(e.target.value);
    this.setState({
      type: e.target.value
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    console.log(e, this.schema);
    this.setState({
      id: Math.floor(Math.random() * 201)
    });
    // this.schema.id = Math.floor(Math.random() * 201);
    this.props.dispatch(action.addItem([this.state]));
    // this.props.addTodo(this.state.item);
    // this.setState({ item: "" }, () => this.refs.item.focus());
  };

  render() {
    const createTypeItems = (item, index) => {
      return (
        <option value={item} key={index}>
          {item}
        </option>
      );
    };
    return (
      <div>
        <h2>input layout</h2>

        <form onSubmit={this.handleSubmit}>
          <input type="text" ref="item" onChange={this.onChange} />
          <select onChange={this.onChangeSelect} value={this.schema_types[0]}>
            {this.schema_types.map(createTypeItems)}
          </select>
          <input type="submit" value="Add" />
        </form>
      </div>
    );
  }
}

export default connect(storeConnect)(TypeInput);
