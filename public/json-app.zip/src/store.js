import { applyMiddleware, createStore } from "redux";

import { createLogger } from "redux-logger";
import thunk from "redux-thunk";
import _ from "lodash";
// import promise from "redux-promise-middleware";

// import reducer from "./reducers";
const initialState = {};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    //
    case "FETCH_ITEMS": {
      const newItems = _.mapKeys(action.payload, "id");
      let stateReturn = { ...state, ...newItems };
      saveToStorage(stateReturn);
      return { ...state, ...newItems };
    }
    case "ADD_ITEM": {
      const newItems = _.mapKeys(action.payload, "id");
      let stateReturn = { ...state, ...newItems };
      saveToStorage(stateReturn);
      return { ...state, ...newItems };
    }
    case "UPDATE_ITEM": {
      return {
        ...state,
        [action.payload.id]: action.payload
      };
    }
    case "REMOVE_ITEM": {
      return _.omit(state, action.payload);
    }
  }
  return state;
};

const saveToStorage = state => {
  console.log(state, _.toArray(state));
  localStorage.setItem("state", JSON.stringify(_.toArray(state)));
};
const middleware = applyMiddleware(thunk, createLogger());

export default createStore(reducer, middleware);
// export default createStore(middleware);
