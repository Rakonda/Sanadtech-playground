import React, { Component } from "react";
import "./App.css";

// export default class Welcome extends Component {
export default class TodoList extends Component {
  static propTypes = {
    // todos: React.PropTypes.array
  };
  /* The propTypes property defines the types of the inputs 
       this component expects. The "todos" input, 
       which we use as (this.props.todos) is expected 
       to be an array of things. 
       If this component receives a "todos" input 
       that is not an array, it would give a warning about it. */

  constructor(props) {
    super(props);
    console.log(this.props);
    this.state = { data: this.props.json || [] };
  }

  addTodo = item => {
    console.log("Item submited to addTodo from Input => ", item);
    item.id = Math.floor(Math.random() * 201);
    this.setState({ data: this.state.data.concat([item]) }, () =>
      console.log(this.state)
    );
  };

  removeTodo = item => {
    this.setState(
      {
        data: this.state.data.filter(person => person.id != item)
      },
      () => console.log(this.state)
    );
  };

  render() {
    return (
      <div>
        <h3>TODO List</h3>
        <TodoInput addTodo={this.addTodo} />
        <TodoItems items={this.state.data} removeTodo={this.removeTodo} />
      </div>
    );
  }
}

class TodoInput extends Component {
  schema = {
    id: 0,
    name: "Default name",
    type: "String",
    items: ""
  };

  schema_types = ["String", "Number", "Array", "Object"];

  constructor(props) {
    super(props);
    this.state = {
      item: this.schema
    };
    // this.test = this.onChange.bind(this);
  }

  onChange = e => {
    this.schema.name = e.target.value;
    this.setState({
      item: this.schema
    });
  };

  onChangeSelect = e => {
    console.log(e.target.value);
    this.schema.type = e.target.value;
    this.setState({
      item: this.schema
    });
  };

  handleSubmit = e => {
    e.preventDefault();
    this.props.addTodo(this.state.item);
    this.setState({ item: "" }, () => this.refs.item.focus());
  };

  render() {
    const createTypeItems = (item, index) => {
      return (
        <option value={item} key={index}>
          {item}
        </option>
      );
    };
    return (
      <form onSubmit={this.handleSubmit}>
        <input type="text" ref="item" onChange={this.onChange} />
        <select onChange={this.onChangeSelect} value={this.state.item.type}>
          {this.schema_types.map(createTypeItems)}
        </select>
        <input type="submit" value="Add" />
      </form>
    );
  }
}

class TodoItems extends Component {
  static propTypes = {
    // items: React.PropTypes.array.isRequired
  };
  /* Here, we're specifying that the “items” props input 
       is an array and it's also required. We can't render 
       a TodoItems element without a value 
       for this input (React will warn if we do). */

  constructor(props) {
    super(props);
    this.state = {
      editing: false,
      text: "ee"
    };
  }

  edit = () => {
    this.setState({
      editing: true
    });
  };

  save = () => {
    var val = this.refs.newText.value;
    alert(val);
    this.setState({
      text: val,
      editing: false
    });
  };

  renderNormal = () => {
    // ** Render "state.text" inside your <p> whether its empty or not...
    return (
      <div>
        <p>{this.state.text}</p>
        <button onClick={this.edit}>Edit</button>
      </div>
    );
  };

  renderForm = () => {
    return (
      <div>
        <textarea ref="newText" defaultValue="Edit me" />
        <button onClick={this.save}>Save</button>
      </div>
    );
  };

  handleClick = (i, e) => {
    console.log(i, e);
    this.props.removeTodo(i);
  };

  render() {
    if (this.state.editing) {
      return this.renderForm();
    } else {
      return this.renderNormal();
    }
    const createItem = (item, index) => {
      return (
        <li key={index} ref="item">
          {item.id} - {item.name} - Index in map=> {index}
          <TodoEditLine />
          <button onClick={this.handleClick.bind(this, item.id)}>Remove</button>
          <button>Edit</button>
        </li>
      );
    };
    return <ul>{this.props.items.map(createItem)}</ul>;
  }
}

class TodoEditLine extends Component {
  constructor(props) {
    super(props);
    this.state = {
      editing: false,
      text: "ee"
    };
  }

  edit = () => {
    this.setState({
      editing: true
    });
  };

  save = () => {
    var val = this.refs.newText.value;
    alert(val);
    this.setState({
      text: val,
      editing: false
    });
  };

  renderNormal = () => {
    // ** Render "state.text" inside your <p> whether its empty or not...
    return (
      <div>
        <p>{this.state.text}</p>
        <button onClick={this.edit}>Edit</button>
      </div>
    );
  };

  renderForm = () => {
    return (
      <div>
        <textarea ref="newText" defaultValue="Edit me" />
        <button onClick={this.save}>Save</button>
      </div>
    );
  };

  render() {
    if (this.state.editing) {
      return this.renderForm();
    } else {
      return this.renderNormal();
    }
  }
}
