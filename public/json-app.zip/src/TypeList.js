import React, { Component } from "react";
import "./App.css";
import { connect } from "react-redux";

const storeConnect = store => {
  return {
    store: store
  };
};

class TypeList extends Component {
  schema = {
    // id: 0,
    name: "Default name",
    type: "String",
    items: ""
  };

  schema_types = ["String", "Number", "Array", "Object"];

  constructor(props) {
    super(props);
    // localStorage.setItem('state', 'off');
  }

  //   onChange = e => {
  //     this.schema.name = e.target.value;
  //     this.setState({
  //       item: this.schema
  //     });
  //   };

  //   onChangeSelect = e => {
  //     console.log(e.target.value);
  //     this.schema.type = e.target.value;
  //     this.setState({
  //       item: this.schema
  //     });
  //   };

  //   handleSubmit = e => {
  //     e.preventDefault();
  //     this.props.addTodo(this.state.item);
  //     this.setState({ item: "" }, () => this.refs.item.focus());
  //   };

  render() {
    const createTypeItems = (item, index) => {
      return (
        <li key={index}>
          {index}
          {this.props.store[item].name}
        </li>
      );
    };
    return (
      <div>
        <h1>input List</h1>
        <ul>{Object.keys(this.props.store).map(createTypeItems)}</ul>
      </div>
    );
  }
}
export default connect(storeConnect)(TypeList);
